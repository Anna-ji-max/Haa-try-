# FocusGuard 1.4

FocusGuard uses an Android AccessibilityService to place accessibility overlays over Instagram and restrict distracting navigation while leaving the Instagram bottom navigation usable.

## Behavior
- Accessibility events are evaluated immediately; there is no debounce timer.
- A 16 ms fallback watchdog keeps checking while Instagram is active.
- Search and Reels remain on their own page but their content is covered by a motivational message.
- The Instagram bottom navigation is excluded from all overlay rectangles.
- Home: content below Stories is hidden; the header remains visible.
- Stories: taps and horizontal swipes are allowed; vertical swipes are blocked.
- Outside Stories, horizontal/vertical swipes are consumed; taps are replayed.
- Profile: header remains visible; lower Highlights/Posts/Reels/Tagged region is hidden.
- A directly opened shared Reel/post can be viewed but cannot be swiped to another item.

Android's accessibility APIs are event-driven, but an accessibility hierarchy can sometimes be stale or change without a useful event. The service therefore combines immediate callbacks with a short fallback poll. This reduces latency but cannot guarantee literally zero milliseconds because Android and Instagram control event delivery and rendering.
