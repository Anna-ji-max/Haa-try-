package com.example.focusguard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.res.Configuration
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

private const val IG = "com.instagram.android"
private const val FAST_TICK = 16L

private val TAB_BAR_IDS = listOf("tab_bar", "bottom_tab_bar")
private val HOME_TAB_IDS = listOf("feed_tab", "home_tab")
private val SEARCH_TAB_IDS = listOf("search_tab", "search_tab_button")
private val REELS_TAB_IDS = listOf("clips_tab", "reels_tab")
private val DIRECT_TAB_IDS = listOf("direct_tab", "direct_tab_button", "action_bar_inbox", "inbox_tab", "messenger_tab")
private val PROFILE_TAB_IDS = listOf("profile_tab", "profile_tab_button")
private val SEARCH_BOX_IDS = listOf("action_bar_search_edit_text", "search_edit_text")
private val REEL_PLAYER_IDS = listOf("reel_recycler", "reel_player_page_container", "clips_view_pager", "reel_viewer_root")

private val DARK_BG = 0xFF0C0F14.toInt()
private val LIGHT_BG = 0xFFFFFFFF.toInt()

data class Colors(val bg: Int, val text: Int, val sub: Int, val accent: Int)

object Palette {
    private val LIGHT = Colors(LIGHT_BG, 0xFF262626.toInt(), 0xFF737373.toInt(), 0xFF0095F6.toInt())
    private val DARK = Colors(DARK_BG, 0xFFFAFAFA.toInt(), 0xFFA8A8A8.toInt(), 0xFF0095F6.toInt())

    fun now(c: Context): Colors {
        val night = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val saver = (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
        return if (night || saver) DARK else LIGHT
    }
}

object Quotes {
    val full = listOf(
        "You came here for a reason. Go do that.",
        "Your time is the one thing you can't scroll back.",
        "Be where your feet are.",
        "Close the feed. Open your day.",
        "Nothing here is as good as what you're about to do."
    )
}

class GuardService : AccessibilityService() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val views = HashMap<String, View>()
    private val rects = HashMap<String, Rect>()

    private var instagramActive = false
    private var watchdogRunning = false
    private var lastScreenKey = ""
    private var lastDirectAt = 0L

    private val watchdog = object : Runnable {
        override fun run() {
            if (!instagramActive || !::wm.isInitialized) {
                watchdogRunning = false
                return
            }
            val root = rootInActiveWindow
            if (root?.packageName?.toString() != IG) {
                instagramActive = false
                watchdogRunning = false
                hideAll()
                return
            }
            // Fast fallback only. Accessibility callbacks do the first reaction.
            evaluate(root)
            ui.postDelayed(this, FAST_TICK)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        evaluate(rootInActiveWindow)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString()
        if (packageName != IG) {
            // A non-Instagram event is also useful for noticing that Instagram was left.
            if (instagramActive) {
                val root = rootInActiveWindow
                if (root?.packageName?.toString() != IG) {
                    instagramActive = false
                    hideAll()
                }
            }
            return
        }

        instagramActive = true
        startWatchdog()

        // Do not wait for a debounce timer. Window changes, tab switches and content
        // changes are evaluated immediately on the service's main thread.
        evaluate(rootInActiveWindow)
    }

    override fun onInterrupt() {
        instagramActive = false
        stopWatchdog()
        hideAll()
    }

    override fun onDestroy() {
        instagramActive = false
        stopWatchdog()
        hideAll()
        super.onDestroy()
    }

    private fun startWatchdog() {
        if (watchdogRunning || !::wm.isInitialized) return
        watchdogRunning = true
        ui.removeCallbacks(watchdog)
        ui.post(watchdog)
    }

    private fun stopWatchdog() {
        ui.removeCallbacks(watchdog)
        watchdogRunning = false
    }

    private fun evaluate(root: AccessibilityNodeInfo?) {
        if (!::wm.isInitialized) return
        if (root == null || root.packageName?.toString() != IG) {
            instagramActive = false
            stopWatchdog()
            hideAll()
            return
        }

        val screen = bounds(root)
        val bottomNavTop = findBottomNavTop(root, screen)
        val contentBottom = bottomNavTop.coerceIn(screen.top + dp(120), screen.bottom)

        val search = isSelected(root, SEARCH_TAB_IDS) || first(root, SEARCH_BOX_IDS)?.isFocused == true || looksLikeSearch(root)
        val reels = isSelected(root, REELS_TAB_IDS) || looksLikeReels(root)
        val direct = isDirectScreen(root)
        val profile = isProfile(root)
        val reelViewer = REEL_PLAYER_IDS.any { find(root, it) != null }
        val home = !search && !reels && !direct && !profile && (isSelected(root, HOME_TAB_IDS) || looksLikeHome(root, screen))

        val screenKey = when {
            search -> "search"
            reels -> "reels"
            profile -> "profile"
            direct -> "direct"
            home -> "home"
            reelViewer -> "viewer"
            else -> "other"
        }
        lastScreenKey = screenKey

        // The DM itself remains usable. A directly opened shared viewer is handled below.
        if (direct) {
            lastDirectAt = System.currentTimeMillis()
            hideAll()
            // DM browsing itself gets no horizontal navigation: only taps and the bottom bar work.
            showGesture("global", Rect(screen.left, screen.top, screen.right, contentBottom), horizontalAllowed = false)
            return
        }

        val sharedViewer = reelViewer && System.currentTimeMillis() - lastDirectAt < 10_000L && !search && !reels && !profile

        if (search) {
            hideAll()
            showMessage("full", Rect(screen.left, screen.top, screen.right, contentBottom), quoteFor("search"))
            return
        }

        if (reels) {
            hideAll()
            showMessage("full", Rect(screen.left, screen.top, screen.right, contentBottom), quoteFor("reels"))
            return
        }

        if (sharedViewer) {
            hideAll()
            val viewer = findViewerRect(root, screen, contentBottom)
            // Shared item is viewable, but no horizontal/vertical swipe can advance it.
            showGesture("shared", viewer, horizontalAllowed = false)
            return
        }

        hide("full")
        hide("shared")
        hide("profile")
        hide("feed")
        hide("global")
        hide("globalTop")
        hide("globalBottom")
        hide("stories")

        if (profile) {
            // Preserve the profile header. Everything from the actual lower-content
            // transition (highlights/tabs/posts) down to the Instagram bottom bar is hidden.
            val protectedTop = profileProtectedTop(root, screen)
            if (contentBottom > protectedTop + dp(8)) {
                showBlank("profile", Rect(screen.left, protectedTop, screen.right, contentBottom))
            }
            // Horizontal/vertical scrolling in the visible profile header is disabled.
            showGesture("globalTop", Rect(screen.left, screen.top, screen.right, protectedTop), horizontalAllowed = false)
            return
        }

        if (home) {
            val story = findStoryRect(root, screen) ?: fallbackStoryRect(screen)
            val storyTop = story.top.coerceIn(screen.top, contentBottom)
            val storyBottom = story.bottom.coerceIn(storyTop, contentBottom)

            // Everything outside Stories is gesture-locked. Bottom navigation is outside
            // the overlay entirely, so it remains fully clickable.
            if (storyTop > screen.top) {
                showGesture("globalTop", Rect(screen.left, screen.top, screen.right, storyTop), horizontalAllowed = false)
            }
            if (contentBottom > storyBottom) {
                showGesture("globalBottom", Rect(screen.left, storyBottom, screen.right, contentBottom), horizontalAllowed = false)
                showBlank("feed", Rect(screen.left, storyBottom, screen.right, contentBottom))
            }

            // Stories are the ONLY place where horizontal swipes are replayed.
            if (storyBottom > storyTop + dp(30)) {
                showGesture("stories", Rect(screen.left, storyTop, screen.right, storyBottom), horizontalAllowed = true)
            }
            return
        }

        // Unknown Instagram content: do not let horizontal swipes move between tabs/pages.
        // Taps are replayed; the bottom navigation is excluded.
        showGesture("global", Rect(screen.left, screen.top, screen.right, contentBottom), horizontalAllowed = false)
    }

    private fun quoteFor(page: String): String {
        val n = ((System.currentTimeMillis() / 7000L).toInt() + page.hashCode())
        return Quotes.full[abs(n) % Quotes.full.size]
    }

    private fun isProfile(root: AccessibilityNodeInfo): Boolean {
        val followers = containsText(root, listOf("Followers"))
        val following = containsText(root, listOf("Following"))
        val action = containsText(root, listOf("Follow", "Message", "Edit profile"))
        return (followers && following && action) || (followers && following && containsText(root, listOf("Posts", "Reels", "Tagged")))
    }

    private fun profileProtectedTop(root: AccessibilityNodeInfo, screen: Rect): Int {
        val highlights = mutableListOf<Rect>()
        collectTextRects(root, listOf("Highlights", "Highlight", "Add highlight", "New highlight"), highlights)
        val tabs = mutableListOf<Rect>()
        collectTextRects(root, listOf("Posts", "Reels", "Tagged", "Tagged posts"), tabs)

        val h = highlights.filter { it.top > screen.top + dp(120) }.minByOrNull { it.top }?.top
        if (h != null) return (h - dp(16)).coerceAtLeast(screen.top)

        val t = tabs.filter { it.top > screen.top + dp(120) }.minByOrNull { it.top }?.top
        if (t != null) return (t - dp(12)).coerceAtLeast(screen.top)

        // If labels are hidden by the current Instagram build, locate the lowest profile
        // metadata/action element and start the protected area shortly after it.
        val header = mutableListOf<Rect>()
        collectTextRects(root, listOf("Followers", "Following", "Follow", "Message", "Edit profile", "Share profile", "Contact"), header)
        val bottom = header.filter { it.top < screen.top + screen.height() * .75f }.maxByOrNull { it.bottom }?.bottom
        if (bottom != null) return (bottom + dp(52)).coerceAtMost(screen.bottom)

        return (screen.top + screen.height() * .42f).toInt()
    }

    private fun findStoryRect(root: AccessibilityNodeInfo, screen: Rect): Rect? {
        val ids = listOf("reel_tray_container", "stories_tray", "story_tray", "row_feed_story")
        val byId = ids.asSequence().mapNotNull { find(root, it) }.map { bounds(it) }
            .filter { it.width() > screen.width() * .55 && it.top < screen.top + screen.height() * .45f }
            .maxByOrNull { it.bottom }
        if (byId != null) return Rect(screen.left, byId.top, screen.right, byId.bottom)

        val nodes = mutableListOf<Rect>()
        collectTextRects(root, listOf("Your story", "story", "stories"), nodes)
        if (nodes.isNotEmpty()) {
            val c = nodes.filter { it.top > screen.top + dp(50) && it.top < screen.top + screen.height() * .42f }
            if (c.isNotEmpty()) return Rect(screen.left, (c.minOf { it.top } - dp(42)).coerceAtLeast(screen.top), screen.right, (c.maxOf { it.bottom } + dp(54)).coerceAtMost(screen.bottom))
        }
        return null
    }

    private fun fallbackStoryRect(screen: Rect): Rect {
        // Conservative startup estimate: header remains untouched and the row ends before the feed.
        val top = screen.top + (screen.height() * 0.12f).toInt()
        val bottom = screen.top + (screen.height() * 0.28f).toInt()
        return Rect(screen.left, top, screen.right, bottom.coerceAtMost(screen.bottom))
    }

    private fun findViewerRect(root: AccessibilityNodeInfo, screen: Rect, contentBottom: Int): Rect {
        val viewer = REEL_PLAYER_IDS.asSequence().mapNotNull { find(root, it) }.map { bounds(it) }
            .firstOrNull { it.width() > screen.width() * .55 && it.height() > dp(250) }
        return viewer ?: Rect(screen.left, screen.top, screen.right, contentBottom)
    }

    private fun looksLikeSearch(root: AccessibilityNodeInfo): Boolean =
        containsText(root, listOf("Search Instagram", "Search")) && !containsText(root, listOf("Followers", "Following"))

    private fun looksLikeReels(root: AccessibilityNodeInfo): Boolean =
        containsText(root, listOf("Reels")) && (REEL_PLAYER_IDS.any { find(root, it) != null } || containsText(root, listOf("Share", "Comment")))

    private fun looksLikeHome(root: AccessibilityNodeInfo, screen: Rect): Boolean =
        findStoryRect(root, screen) != null && (isSelected(root, HOME_TAB_IDS) || first(root, TAB_BAR_IDS) != null)

    private fun isDirectScreen(root: AccessibilityNodeInfo): Boolean = isSelected(root, DIRECT_TAB_IDS)

    private fun findBottomNavTop(root: AccessibilityNodeInfo, screen: Rect): Int {
        val tabBar = first(root, TAB_BAR_IDS)
        if (tabBar != null) {
            val r = bounds(tabBar)
            if (r.top > screen.top + dp(300) && r.bottom <= screen.bottom + dp(20)) return r.top
        }

        val labels = mutableListOf<Rect>()
        collectTextRects(root, listOf("Home", "Reels", "Search", "Profile", "Messages"), labels)
        val lower = labels.filter { it.top > screen.top + screen.height() * .65f }
        if (lower.isNotEmpty()) return (lower.minOf { it.top } - dp(18)).coerceAtLeast(screen.top + dp(200))

        return screen.bottom - (screen.height() * 0.11f).toInt()
    }

    private inner class GestureGate(context: Context, private val horizontalAllowed: Boolean) : View(context) {
        private var downX = 0f
        private var downY = 0f
        private var moved = false
        private val threshold = dp(10)

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(event.rawX - downX) > threshold || abs(event.rawY - downY) > threshold) moved = true
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (!moved) replayTap(event.rawX, event.rawY)
                    else if (horizontalAllowed && abs(dx) > abs(dy) && abs(dx) > threshold) replaySwipe(downX, downY, event.rawX, event.rawY)
                    // Every other swipe is consumed. This is what prevents tab/page changes by swiping.
                    return true
                }
                MotionEvent.ACTION_CANCEL -> return true
            }
            return true
        }
    }

    private fun replayTap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val s = GestureDescription.StrokeDescription(p, 0, 40)
        dispatchGesture(GestureDescription.Builder().addStroke(s).build(), null, null)
    }

    private fun replaySwipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val s = GestureDescription.StrokeDescription(p, 0, 180)
        dispatchGesture(GestureDescription.Builder().addStroke(s).build(), null, null)
    }

    private fun containsText(node: AccessibilityNodeInfo?, values: List<String>): Boolean {
        if (node == null || !node.isVisibleToUser) return false
        val hay = listOfNotNull(node.text?.toString(), node.contentDescription?.toString()).joinToString(" ")
        if (values.any { hay.contains(it, true) }) return true
        for (i in 0 until node.childCount) if (containsText(node.getChild(i), values)) return true
        return false
    }

    private fun collectTextRects(node: AccessibilityNodeInfo?, labels: List<String>, out: MutableList<Rect>) {
        if (node == null || !node.isVisibleToUser) return
        val text = listOfNotNull(node.text?.toString(), node.contentDescription?.toString()).joinToString(" ")
        if (labels.any { text.equals(it, true) || text.contains(it, true) }) out.add(bounds(node))
        for (i in 0 until node.childCount) collectTextRects(node.getChild(i), labels, out)
    }

    private fun isSelected(root: AccessibilityNodeInfo, ids: List<String>): Boolean =
        ids.asSequence().mapNotNull { find(root, it) }.any { it.isSelected }

    private fun first(root: AccessibilityNodeInfo, ids: List<String>): AccessibilityNodeInfo? =
        ids.asSequence().mapNotNull { find(root, it) }.firstOrNull()

    private fun find(root: AccessibilityNodeInfo, name: String): AccessibilityNodeInfo? =
        root.findAccessibilityNodeInfosByViewId("$IG:id/$name").firstOrNull { it.isVisibleToUser }

    private fun bounds(node: AccessibilityNodeInfo): Rect = Rect().also { node.getBoundsInScreen(it) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showGesture(key: String, rect: Rect, horizontalAllowed: Boolean) {
        val r = clipToScreen(rect)
        if (r.width() <= 0 || r.height() <= 0) { hide(key); return }
        try {
            val existing = views[key]
            if (existing != null) {
                if (rects[key] != r) wm.updateViewLayout(existing, params(r))
            } else {
                val view = GestureGate(this, horizontalAllowed)
                wm.addView(view, params(r))
                views[key] = view
            }
            rects[key] = r
        } catch (_: Exception) { }
    }

    private fun showBlank(key: String, rect: Rect) {
        val r = clipToScreen(rect)
        if (r.width() <= 0 || r.height() <= 0) { hide(key); return }
        try {
            val existing = views[key]
            if (existing != null) {
                if (rects[key] != r) wm.updateViewLayout(existing, params(r))
            } else {
                val v = View(this).apply {
                    setBackgroundColor(Palette.now(this@GuardService).bg)
                    isClickable = true
                    setOnTouchListener { _, _ -> true }
                }
                wm.addView(v, params(r))
                views[key] = v
            }
            rects[key] = r
        } catch (_: Exception) { }
    }

    private fun showMessage(key: String, rect: Rect, message: String) {
        val r = clipToScreen(rect)
        if (r.width() <= 0 || r.height() <= 0) { hide(key); return }
        try {
            val existing = views[key]
            if (existing != null) {
                if (rects[key] != r) wm.updateViewLayout(existing, params(r))
                (existing as? LinearLayout)?.let { (it.getChildAt(0) as? TextView)?.text = message }
            } else {
                val colors = Palette.now(this)
                val v = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setBackgroundColor(colors.bg)
                    setPadding(dp(32), 0, dp(32), 0)
                    isClickable = true
                    setOnTouchListener { _, _ -> true }
                    addView(TextView(context).apply {
                        text = message
                        textSize = 22f
                        gravity = Gravity.CENTER
                        setTextColor(colors.text)
                    })
                }
                wm.addView(v, params(r))
                views[key] = v
            }
            rects[key] = r
        } catch (_: Exception) { }
    }

    private fun clipToScreen(rect: Rect): Rect = Rect(
        rect.left,
        rect.top,
        rect.right,
        rect.bottom
    ).also {
        if (it.top < 0) it.top = 0
        if (it.bottom < it.top) it.bottom = it.top
    }

    private fun hide(key: String) {
        rects.remove(key)
        views.remove(key)?.let { try { wm.removeView(it) } catch (_: Exception) {} }
    }

    private fun hideAll() = views.keys.toList().forEach { hide(it) }

    private fun params(rect: Rect) = WindowManager.LayoutParams(
        rect.width(),
        rect.height(),
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = rect.left
        y = rect.top
    }
}
